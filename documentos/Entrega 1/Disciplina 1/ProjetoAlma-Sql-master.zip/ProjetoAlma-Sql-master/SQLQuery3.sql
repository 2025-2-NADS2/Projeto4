
CREATE DATABASE Projeto;
USE projeto;


CREATE TABLE Usuario (
    cd_cliente NUMERIC(8) PRIMARY KEY,
    nome_usuario VARCHAR(40) NOT NULL,
    email VARCHAR(40) UNIQUE NOT NULL,
    telefone NVARCHAR(15),
    senha VARCHAR(8)
);


CREATE TABLE Campanha (
    cd_campanha NUMERIC(20) PRIMARY KEY,
    nome_campanha VARCHAR(40) NOT NULL,
    meta_arrecadacao DECIMAL(12,2),
    inicio DATE,
    fim DATE
);


CREATE TABLE Doacao (
    cd_doacao NUMERIC(20) PRIMARY KEY,
    cd_cliente NUMERIC(8) NOT NULL,
    cd_campanha NUMERIC(20) NOT NULL,
    nome_doacao VARCHAR(40) NOT NULL,
    tipo_doacao VARCHAR(15) NOT NULL,
    forma_arrecadacao VARCHAR(35) NOT NULL,
    status_arrecadacao VARCHAR(30),
    CONSTRAINT fk_doacao_usuario FOREIGN KEY (cd_cliente)
        REFERENCES Usuario(cd_cliente),
    CONSTRAINT fk_doacao_campanha FOREIGN KEY (cd_campanha)
        REFERENCES Campanha(cd_campanha)
);


CREATE TABLE Relatorio (
    cd_relatorio NUMERIC(20) PRIMARY KEY,
    cd_campanha NUMERIC(20) NOT NULL,
    tipo_relatorio VARCHAR(40),
    valor_gasto DECIMAL(12,2),
    data_relatorio DATE,
    CONSTRAINT fk_relatorio_campanha FOREIGN KEY (cd_campanha)
        REFERENCES Campanha(cd_campanha)
);


CREATE TABLE Noticias (
    cd_noticias NUMERIC(20) PRIMARY KEY,
    titulo_noticia VARCHAR(30) NOT NULL,
    data_noticia DATE,
    autor VARCHAR(40),
    cd_campanha NUMERIC(20),
    CONSTRAINT fk_noticias_campanha FOREIGN KEY (cd_campanha)
        REFERENCES Campanha(cd_campanha)
);


-- �ndices para performance
CREATE INDEX idx_usuario_email
ON Usuario (email);

CREATE INDEX idx_usuario_telefone
ON Usuario (telefone);

CREATE INDEX idx_doacao_cd_campanha
ON Doacao (cd_campanha);

CREATE INDEX idx_doacao_cd_cliente
ON Doacao (cd_cliente);

CREATE INDEX idx_relatorio_cd_campanha
ON Relatorio (cd_campanha);





